"use strict";
exports.id = 5282;
exports.ids = [5282];
exports.modules = {

/***/ 5282:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lE": () => (/* binding */ loadContracts)
/* harmony export */ });
/* unused harmony exports connectWallet, getCurrentWalletConnected, accountChangeHandler, mintNFT */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pinata_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2081);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _nft_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3896);
/* harmony import */ var _marketplace_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4801);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9648);
/* harmony import */ var _utils_axiosInterceptor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7195);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, _utils_axiosInterceptor_js__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, _utils_axiosInterceptor_js__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const loadContracts = async ()=>{
    const provider = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    // Get deployed copies of contracts
    const marketplace = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.Contract("0x71E80Fd0Ca79A699F74400A01C0bA253B3e51413", _marketplace_json__WEBPACK_IMPORTED_MODULE_4__/* .abi */ .M, signer);
    //setMarketplace(marketplace)
    const nft = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.Contract("0xFCDeb411d5155e7eAFA3249d2E963446786a3aD5", _nft_json__WEBPACK_IMPORTED_MODULE_3__/* .abi */ .M, signer);
    //wallet address
    const addressArray = await window.ethereum.request({
        method: "eth_accounts"
    });
    if (addressArray.length > 0) {
        return {
            marketplace: marketplace,
            nft: nft,
            address: addressArray[0],
            status: ""
        };
    } else {
        return {
            address: "",
            status: "\uD83E\uDD8A Connect to Metamask using the top right button."
        };
    }
};
const connectWallet = async ()=>{
    if (window.ethereum) {
        try {
            const addressArray = await window.ethereum.request({
                method: "eth_requestAccounts"
            });
            const obj = {
                status: "Metamask successfuly connected.",
                address: addressArray[0]
            };
            return obj;
        } catch (err) {
            return {
                address: "",
                status: "Something went wrong: " + err.message
            };
        }
    } else {
        return {
            address: "",
            status: /*#__PURE__*/ _jsx("span", {
                children: /*#__PURE__*/ _jsxs("p", {
                    children: [
                        " ",
                        "\uD83E\uDD8A",
                        " ",
                        /*#__PURE__*/ _jsx("a", {
                            target: "_blank",
                            rel: "noreferrer",
                            href: `https://metamask.io/download.html`,
                            children: "You must install Metamask, a virtual Ethereum wallet, in your browser."
                        })
                    ]
                })
            })
        };
    }
};
const getCurrentWalletConnected = async ()=>{
    if (window.ethereum) {
        try {
            const addressArray = await window.ethereum.request({
                method: "eth_accounts"
            });
            if (addressArray.length > 0) {
                return {
                    address: addressArray[0],
                    status: ""
                };
            } else {
                return {
                    address: "",
                    status: "\uD83E\uDD8A Connect to Metamask using the top right button."
                };
            }
        } catch (err) {
            return {
                address: "",
                status: "Something went wrong: " + err.message
            };
        }
    } else {
        return {
            address: "",
            status: /*#__PURE__*/ _jsx("span", {
                children: /*#__PURE__*/ _jsxs("p", {
                    children: [
                        " ",
                        "\uD83E\uDD8A",
                        " ",
                        /*#__PURE__*/ _jsx("a", {
                            target: "_blank",
                            rel: "noreferrer",
                            href: `https://metamask.io/download.html`,
                            children: "You must install Metamask, a virtual Ethereum wallet, in your browser."
                        })
                    ]
                })
            })
        };
    }
};
const accountChangeHandler = async ()=>{
    const { address  } = await getCurrentWalletConnected();
    // Requesting balance method
    const balance = await window.ethereum.request({
        method: "eth_getBalance",
        params: [
            address,
            "latest"
        ]
    });
    return ethers.utils.formatEther(balance);
};
const mintNFT = async (url, name, description, price, minBid, duration, nft, marketplace, auction, select, image, walletAddress)=>{
    if (url === "" || name.trim() === "" || description.trim() === "") {
        return {
            success: false,
            status: "Please make sure all fields are completed before minting.",
            id: 0
        };
    }
    const metadata = {};
    metadata.name = name;
    metadata.image = url;
    metadata.description = description;
    const pinataResponse = await pinJSONToIPFS(metadata);
    if (!pinataResponse.success) {
        return {
            success: false,
            status: "Something went wrong while uploading your tokenURI.",
            id: 0
        };
    }
    const tokenURI = pinataResponse.pinataUrl;
    console.log(tokenURI);
    const link = await nft.mint(tokenURI);
    var nftId;
    if (select === 1) {
        await nft.setApprovalForAll(marketplace.address, true);
        const id = await nft.tokenCount();
        // add nft to marketplace
        const listingPrice = ethers.utils.parseEther(price.toString());
        await marketplace.makeItem(nft.address, id, listingPrice);
        nftId = await marketplace.itemCount();
        if (nftId) {
            const formData = new FormData();
            formData.append("id", nftId);
            formData.append("name", name);
            formData.append("price", price);
            formData.append("nftImage", image);
            formData.append("isBuy", false);
            formData.append("owner", walletAddress);
            await axiosInstance.post("/nft/createNft", formData, {}).then((response)=>console.log(response)
            );
            //activity
            await axiosInstance.post("/activity/", {
                collectionId: "3",
                itemName: name,
                events: "minted",
                price: price,
                from: walletAddress,
                to: "0x00",
                transactionHash: "0x00"
            }).then((response)=>console.log(response)
            );
        }
    } else {
        await nft.setApprovalForAll(auction.address, true);
        const id = await nft.tokenCount();
        // add nft to marketplace
        const listingPrice = ethers.utils.parseEther(minBid.toString());
        duration = new Date(duration).getTime() / 1000;
        await auction.createTokenAuction(nft.address, id, listingPrice, duration);
        nftId = await auction.itemCount();
        const item = await auction.items(nftId);
        //const aucitem = await auction.getTokenAuctionDetails(item.nft, item.tokenID)
        if (nftId) {
            const formData = new FormData();
            formData.append("id", item.tokenID);
            formData.append("name", name);
            formData.append("minbid", minBid);
            formData.append("curbid", 0);
            formData.append("duration", duration);
            formData.append("nftImage", image);
            formData.append("isBuy", false);
            formData.append("owner", walletAddress);
            await axiosInstance.post("/Anft/createAuctionNft", formData, {}).then((response)=>console.log(response)
            );
            //activity
            await axiosInstance.post("/activity/", {
                collectionId: "4",
                itemName: name,
                events: "auction",
                price: minBid,
                from: walletAddress,
                to: "0x00",
                transactionHash: "0x00"
            }).then((response)=>console.log(response)
            );
        }
    }
    return {
        success: true,
        status: "Check out your transaction on Etherscan: https://testnet.bscscan.com/tx/" + link.hash,
        id: nftId
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ pinJSONToIPFS)
/* harmony export */ });
const key = "7b8121c59dfc78c4098a";
const secret = "b5dde682e1cbff9fce2dde1b5b6061d71ea9fc4c9e146562a2b7efa0834926af";
const axios = __webpack_require__(2167);
const pinJSONToIPFS = async (JSONBody)=>{
    const url = `https://api.pinata.cloud/pinning/pinJSONToIPFS`;
    return axios.post(url, JSONBody, {
        headers: {
            pinata_api_key: key,
            pinata_secret_api_key: secret
        }
    }).then(function(response) {
        return {
            success: true,
            pinataUrl: "https://gateway.pinata.cloud/ipfs/" + response.data.IpfsHash
        };
    }).catch(function(error) {
        console.log(error);
        return {
            success: false,
            message: error.message
        };
    });
};


/***/ }),

/***/ 4801:
/***/ ((module) => {

module.exports = JSON.parse('{"M":[{"inputs":[{"internalType":"uint256","name":"_feePercent","type":"uint256"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"itemId","type":"uint256"},{"indexed":true,"internalType":"address","name":"nft","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"},{"indexed":true,"internalType":"address","name":"seller","type":"address"},{"indexed":true,"internalType":"address","name":"buyer","type":"address"}],"name":"Bought","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"itemId","type":"uint256"},{"indexed":true,"internalType":"address","name":"nft","type":"address"},{"indexed":false,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"},{"indexed":true,"internalType":"address","name":"seller","type":"address"}],"name":"Offered","type":"event"},{"inputs":[],"name":"feeAccount","outputs":[{"internalType":"address payable","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"feePercent","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_itemId","type":"uint256"}],"name":"getTotalPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"itemCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"items","outputs":[{"internalType":"uint256","name":"itemId","type":"uint256"},{"internalType":"contract IERC721","name":"nft","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"address payable","name":"seller","type":"address"},{"internalType":"bool","name":"sold","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"contract IERC721","name":"_nft","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"uint256","name":"_price","type":"uint256"}],"name":"makeItem","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_itemId","type":"uint256"}],"name":"purchaseItem","outputs":[],"stateMutability":"payable","type":"function"}]}');

/***/ }),

/***/ 3896:
/***/ ((module) => {

module.exports = JSON.parse('{"M":[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_tokenURI","type":"string"}],"name":"mint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"tokenCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"}]}');

/***/ })

};
;