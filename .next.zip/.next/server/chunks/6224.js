"use strict";
exports.id = 6224;
exports.ids = [6224];
exports.modules = {

/***/ 7195:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

console.log("env call", "http://localhost:5500");
const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: `${"http://localhost:5500"}`
});
axiosInstance.interceptors.request.use((req)=>{
    req.headers = {
        ...req.headers
    };
    return req;
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosInstance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1975:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OK": () => (/* binding */ saveItem),
/* harmony export */   "rV": () => (/* binding */ getItem)
/* harmony export */ });
/* unused harmony export deleteItem */
/* eslint-disable no-empty */ const getItem = (key)=>{
    try {
        const serializedState = localStorage.getItem(key);
        if (serializedState == null) {
            return undefined;
        }
        return serializedState;
    } catch (err) {
        return undefined;
    }
};
const saveItem = (state, key)=>{
    try {
        localStorage.setItem(key, state);
    } catch (err) {}
};
const deleteItem = (key)=>{
    try {
        localStorage.removeItem(key);
    } catch (e) {}
};


/***/ })

};
;