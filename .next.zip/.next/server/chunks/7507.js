"use strict";
exports.id = 7507;
exports.ids = [7507];
exports.modules = {

/***/ 7507:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ Metamask_comp_text),
/* harmony export */   "hC": () => (/* binding */ Metamask_comp_icon),
/* harmony export */   "tq": () => (/* binding */ Metamask_comp_login)
/* harmony export */ });
/* unused harmony export Confirm_checkout */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var metamask_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9409);
/* harmony import */ var metamask_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(metamask_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_counterSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4954);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var _utils_axiosInterceptor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7195);
/* harmony import */ var _utils_localStorage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1975);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__, _utils_axiosInterceptor__WEBPACK_IMPORTED_MODULE_9__]);
([axios__WEBPACK_IMPORTED_MODULE_8__, _utils_axiosInterceptor__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Metamask_comp_text = ()=>{
    const { status , connect , account , ethereum  } = (0,metamask_react__WEBPACK_IMPORTED_MODULE_2__.useMetaMask)();
    if (status === "initializing") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "js-wallet bg-accent shadow-accent-volume hover:bg-accent-dark block w-full rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "Synchronisation with MetaMask ongoing..."
    });
    if (status === "unavailable") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "js-wallet bg-accent shadow-accent-volume hover:bg-accent-dark block w-full rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "MetaMask not available :"
    });
    if (status === "notConnected") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "js-wallet bg-accent shadow-accent-volume hover:bg-accent-dark block w-full rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        onClick: connect,
        children: "Connect Wallet"
    });
    if (status === "connecting") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "js-wallet bg-accent shadow-accent-volume hover:bg-accent-dark block w-full rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "Connecting..."
    });
    if (status === "connected") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: "js-wallet bg-accent shadow-accent-volume hover:bg-accent-dark block w-full rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
            onClick: ()=>dispatch((0,_redux_counterSlice__WEBPACK_IMPORTED_MODULE_4__/* .walletModalShow */ .zI)())
            ,
            children: "Connect Wallet"
        })
    });
};
const Metamask_comp_login = ()=>{
    const { loggedin  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.counter
    );
    const { 0: haveMetamask , 1: setHaveMetamask  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: accountAddress , 1: setAccountAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: accountBalance , 1: setAccountBalance  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: isConnected , 1: setIsConnected  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: error1 , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        status: false,
        message: ""
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const { ethereum  } = window;
        console.log(ethereum);
        const checkMetamaskAvailability = async ()=>{
            if (ethereum) {
                setHaveMetamask(true);
            }
            if ((0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_10__/* .getItem */ .rV)("userAddress")) {
                setAccountAddress((0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_10__/* .getItem */ .rV)("userAddress"));
            }
        };
        checkMetamaskAvailability();
    }, []);
    // console.log(
    //   "statuses",
    //   { haveMetamask },
    //   { accountBalance },
    //   { accountAddress },
    //   { isConnected }
    // );
    // const { status, connect, account, chainId, ethereum } = useMetaMask();
    // console.log({ status, connect, account, chainId, ethereum });
    // if (status === "initializing") {
    //   return (
    //     <button className="js-wallet bg-accent hover:bg-accent-dark mb-4 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all">
    //       <Image
    //         src="/images/wallets/metamask_24.svg"
    //         className="mr-2.5 inline-block h-6 w-6"
    //         alt=""
    //         height={24}
    //         width={24}
    //       />
    //       <span className="ml-2.5">Metamask initializing</span>
    //     </button>
    //   );
    // }
    // if (status === "unavailable") {
    //   return (
    //     <button className="js-wallet bg-accent hover:bg-accent-dark mb-4 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all">
    //       <Image
    //         src="/images/wallets/metamask_24.svg"
    //         className="mr-2.5 inline-block h-6 w-6"
    //         alt=""
    //         height={24}
    //         width={24}
    //       />
    //       <span className="ml-2.5">unavailable</span>
    //     </button>
    //   );
    // }
    // if (status === "notConnected")
    //   return (
    //     <>
    //       <button
    //         className="js-wallet bg-accent hover:bg-accent-dark mb-4 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all"
    //         onClick={connect}
    //       >
    //         <Image
    //           src="/images/wallets/metamask_24.svg"
    //           className="inline-block h-6 w-6"
    //           alt=""
    //           height={24}
    //           width={24}
    //         />
    //         <span className="ml-2.5">Sign in with Metamask</span>
    //       </button>
    //     </>
    //   );
    // if (status === "connecting")
    //   return (
    //     <button className="js-wallet bg-accent hover:bg-accent-dark mb-4 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all">
    //       <Image
    //         src="/images/wallets/metamask_24.svg"
    //         className="mr-2.5 inline-block h-6 w-6"
    //         alt=""
    //         height={24}
    //         width={24}
    //       />
    //       <span className="ml-2.5">Metamask connecting</span>
    //     </button>
    //   );
    // if (status === "notConnected");
    // var Eth = require("web3-eth");
    // const web3 = require("web3");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const handleSubmit = async ()=>{
        const { ethereum  } = window;
        const provider = new ethers__WEBPACK_IMPORTED_MODULE_7__.ethers.providers.Web3Provider(window.ethereum);
        try {
            if (!ethereum) {
                setHaveMetamask(false);
            }
            const accounts = await ethereum.request({
                method: "eth_requestAccounts"
            });
            let balance = await provider.getBalance(accounts[0]);
            let bal = ethers__WEBPACK_IMPORTED_MODULE_7__.ethers.utils.formatEther(balance);
            setAccountAddress(accounts[0]);
            setAccountBalance(bal);
            setIsConnected(true);
            _utils_axiosInterceptor__WEBPACK_IMPORTED_MODULE_9__/* ["default"].post */ .Z.post("/user/login", {
                address: accounts[0],
                balance: bal
            }).then((res)=>{
                (0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_10__/* .saveItem */ .OK)(accounts[0], "userAddress");
                (0,_utils_localStorage__WEBPACK_IMPORTED_MODULE_10__/* .saveItem */ .OK)(bal, "userBalance");
                dispatch((0,_redux_counterSlice__WEBPACK_IMPORTED_MODULE_4__/* .Logintrue */ .bY)());
                router.push("/");
            }).catch((err)=>{
                setError({
                    status: true,
                    message: err.message
                });
                return;
            });
        } catch (error) {
            setError({
                status: true,
                message: error.message
            });
            setIsConnected(false);
        }
    };
    // const handleSubmit = async (event) => {
    //   event.preventDefault();
    //   connect()
    //     .then(() => {
    //       console.log(account);
    //     })
    //     .catch((error) => {
    //       console.log(error);
    //     });
    //   console.log("Account Address = " + account);
    //   // var eth = new Eth(Eth.givenProvider);
    //   // console.log(eth); // Null
    //   // const balance = await eth.getBalance(account);
    //   // console.log(balance);
    //   // console.log(account);
    //   // const req = await axiosInstance
    //   //   .post("/user/login", {
    //   //     address: account,
    //   //     balance: balance,
    //   //   })
    //   //   .catch((err) => {
    //   //     console.log(err);
    //   //     return;
    //   //   });
    //   // dispatch(Logintrue());
    //   // console.log(req);
    //   // router.push("/");
    // };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: haveMetamask ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: isConnected ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            accountAddress.slice(0, 4),
                            "..."
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            accountAddress.slice(38, 42),
                            "..."
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Balance"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: accountBalance
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "js-wallet bg-accent hover:bg-accent-dark mb-1 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all",
                        onClick: handleSubmit,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                src: "/images/wallets/metamask_24.svg",
                                className: " inline-block h-6 w-6",
                                alt: "",
                                height: 24,
                                width: 24
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ml-2.5",
                                children: "Sign in with Metamask"
                            })
                        ]
                    }),
                    error1.status && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-red mx-auto max-w-md text-center text-small",
                        children: error1.message
                    }),
                    loggedin && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "text-green mx-auto max-w-md text-center text-small",
                        children: [
                            "LoggedIn with address :",
                            " ",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-red mx-auto max-w-md text-center text-small",
                                children: [
                                    accountAddress.slice(0, 4),
                                    "...",
                                    accountAddress.slice(38, 42)
                                ]
                            })
                        ]
                    })
                ]
            })
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            className: "js-wallet opacity-50 cursor-not-allowed bg-red hover:bg-red-dark mb-1 flex w-full items-center justify-center rounded-full border-2 border-transparent py-4 px-8 text-center font-semibold text-white transition-all",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                    src: "/images/wallets/metamask_24.svg",
                    className: " inline-block h-6 w-6",
                    alt: "",
                    height: 24,
                    width: 24
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "ml-2.5",
                    children: "First Install MetaMask"
                })
            ]
        })
    });
};
const Confirm_checkout = ()=>{
    const { status , connect , account , chainId , ethereum  } = useMetaMask();
    if (status === "initializing") return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "initializing"
    });
    if (status === "unavailable") return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "unavailable"
    });
    if (status === "notConnected") return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        onClick: connect,
        children: "Confirm Checkout"
    });
    if (status === "connecting") return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "connecting"
    });
    if (status === "connected") return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "bg-accent shadow-accent-volume hover:bg-accent-dark rounded-full py-3 px-8 text-center font-semibold text-white transition-all",
        children: "Confirm Checkout"
    });
};
const Metamask_comp_icon = ({ prop  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const { status , connect , account , chainId , ethereum  } = (0,metamask_react__WEBPACK_IMPORTED_MODULE_2__.useMetaMask)();
    if (status === "initializing") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: prop.asPath === "/home/home_3" ? "js-wallet border-jacarta-100  focus:bg-accent group hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]" : "js-wallet border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 24 24",
                width: "24",
                height: "24",
                className: prop.asPath === "/home/home_3" ? " h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white fill-white" : "fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        fill: "none",
                        d: "M0 0h24v24H0z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M22 6h-7a6 6 0 1 0 0 12h7v2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v2zm-7 2h8v8h-8a4 4 0 1 1 0-8zm0 3v2h3v-2h-3z"
                    })
                ]
            })
        })
    });
    if (status === "unavailable") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: prop.asPath === "/home/home_3" ? "js-wallet border-jacarta-100  focus:bg-accent group hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]" : "js-wallet border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 24 24",
                width: "24",
                height: "24",
                className: prop.asPath === "/home/home_3" ? " h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white fill-white" : "fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        fill: "none",
                        d: "M0 0h24v24H0z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M22 6h-7a6 6 0 1 0 0 12h7v2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v2zm-7 2h8v8h-8a4 4 0 1 1 0-8zm0 3v2h3v-2h-3z"
                    })
                ]
            })
        })
    });
    // if (status === "notConnected")
    //   return (
    //     <button
    //       className={
    //         prop.asPath === "/home/home_3"
    //           ? "js-wallet border-jacarta-100  focus:bg-accent group hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]"
    //           : "js-wallet border-jacarta-100 hover:bg-accent focus:bg-accent group dark:hover:bg-accent flex h-10 w-10 items-center justify-center rounded-full border bg-white transition-colors hover:border-transparent focus:border-transparent dark:border-transparent dark:bg-white/[.15]"
    //       }
    //       // onClick={() => dispatch(walletModalShow())}
    //       onClick={connect}
    //     >
    //       <svg
    //         xmlns="http://www.w3.org/2000/svg"
    //         viewBox="0 0 24 24"
    //         width="24"
    //         height="24"
    //         className={
    //           prop.asPath === "/home/home_3"
    //             ? " h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white fill-white"
    //             : "fill-jacarta-700 h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white dark:fill-white"
    //         }
    //       >
    //         <path fill="none" d="M0 0h24v24H0z"></path>
    //         <path d="M22 6h-7a6 6 0 1 0 0 12h7v2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1v2zm-7 2h8v8h-8a4 4 0 1 1 0-8zm0 3v2h3v-2h-3z"></path>
    //       </svg>
    //     </button>
    //   );
    if (status === "connecting") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
    if (status === "connected") return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;